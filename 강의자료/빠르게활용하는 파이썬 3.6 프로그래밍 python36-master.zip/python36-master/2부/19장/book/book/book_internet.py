print("book internet")
